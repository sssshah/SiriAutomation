terraform destroy -input=false -auto-approve
#terraform plan -destroy -out=tfdestroy.out
#terraform apply tfdestroy.out -auto-approve
