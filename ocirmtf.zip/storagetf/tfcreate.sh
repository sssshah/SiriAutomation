terraform init -input=false
terraform plan -input=false -out=tfplan.out
terraform apply tfplan.out
